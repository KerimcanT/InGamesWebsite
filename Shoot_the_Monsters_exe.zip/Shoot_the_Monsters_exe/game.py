import sprites_load
import show_enemies
import tkinter
import os
import sys
import pygame
import time
import random

ending_time = None

jumping = False

frozen = False
frozen_time = 0

shop = False 

last_give_freeze = int(time.time())

falling = False

read = None
read_file = "Save not found"
save = []

if os.path.exists("save.txt"):
    read = open("save.txt", "r")
    read_file = read.read()

for i in read_file.split(" "):
    if not i == '' and not i == "\n":
        save.append(i)

info = tkinter.Tk()

pygame.init()
pygame.mixer.init()

screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
pygame.display.set_caption("Zombies!")

dynamite_threw = False
thrown_time = 0

episode_time = time.time()

meteor1y = -100
meteor2y = -200
meteor3y = -300
meteor4y = -400
meteor5y = -500

positionx = 0

quest_two = False
quest_one = False

last_attack_time1 = None
last_attack_time2 = None

missile1x = -100
missile2x = info.winfo_screenwidth() + 700

page1 = True
page2 = False

if not read:
    if os.path.exists("money.txt"):
        m = open("money.txt")

        money = int(m.read())

        m.close()
    else:
        money = 0

    freeze_left = 0
    quest_one = False
    dynamites_left = 0
    starting_time = 0

    episode_time = 0

    bullets_left = 10
    grenades_left = 0

    walk_right = False
    walk_left = False

    walk_index = 0

    level_up_time = 0

    characterx = info.winfo_screenwidth() / 2
    charactery = info.winfo_screenheight() - 190

    life_loss = 0

    grenade_time_start = 0

    facing_left = False
    facing_right = True

    fired_left = False
    fired_right = False

    grenade_threw = False

    fired_time = 0

    font = pygame.font.Font("freesansbold.ttf", 20)
    bigger_font = pygame.font.Font("freesansbold.ttf", 40)

    retreat = None

    target = None

    entity1x = -100

    entity3x = -300
    entity5x = -500

    shotgun_pistol_ammo = 5
    last_given_spammo = 0

    last_give_dynamite = 0

    entity2x = info.winfo_screenwidth() + 200
    entity4x = info.winfo_screenwidth() + 400
    entity6x = info.winfo_screenwidth() + 600

    enemy_y = info.winfo_screenheight() - 190

    zombie_anim_index = 0

    shoot = False

    first_start = True

    gun = 1

    original_lives = 1

    last_given_bullet = 0
    last_given_grenade = 0

    grenadex = 1440 / 2
    grenadey = 0

    first = True

    first_time_sound = True

    rifle_ammo = 3

    entity_type = "zombie"

    background = sprites_load.background

    entity1_lives = original_lives
    entity2_lives = original_lives
    entity3_lives = original_lives

    entity4_lives = original_lives
    entity5_lives = original_lives
    entity6_lives = original_lives

    remained_lives = 3

else:
    if os.path.exists("level_save"):
        c = open("level_save", "r")
        if c.read() == "quest 2":
            quest_two = True
    elif not os.path.exists("level_save"):
        quest_one = True

    m = open("money.txt", "r")

    money = int(m.read())

    m.close()

    last_give_dynamite = 0
    starting_time = time.time() - float(save[12])

    freeze_left = int(save[-1])

    bullets_left = int(save[15])
    grenades_left = float(save[-4])

    walk_right = False
    walk_left = False

    walk_index = 0

    level_up_time = 0

    characterx = float(save[13])
    charactery = info.winfo_screenheight() - 190

    life_loss = 0

    grenade_time_start = 0

    facing_left = False
    facing_right = True

    fired_left = False
    fired_right = False

    grenade_threw = False

    fired_time = 0

    font = pygame.font.Font("freesansbold.ttf", 20)
    bigger_font = pygame.font.Font("freesansbold.ttf", 40)

    retreat = None

    target = None

    entity1x = int(save[6])

    entity3x = int(save[8])
    entity5x = int(save[10])

    shotgun_pistol_ammo = int(save[17])
    last_given_spammo = 0

    entity2x = int(save[7])
    entity4x = int(save[9])
    entity6x = int(save[11])

    enemy_y = info.winfo_screenheight() - 190

    zombie_anim_index = 0

    shoot = False

    first_start = True

    gun = 1

    original_lives = 1

    last_given_bullet = 0
    last_given_grenade = 0

    grenadex = 1440 / 2
    grenadey = 0

    first = True

    first_time_sound = True

    rifle_ammo = int(save[16])

    entity_type = save[-3]

    dynamites_left = int(save[-2])

    if entity_type == "zombie":
        episode_time = time.time() - (time.time() - starting_time)
    elif entity_type == "dino":
        episode_time = time.time() - (time.time() - starting_time) + 311
    elif entity_type == "orc":
        episode_time = time.time() - (time.time() - starting_time) + 622
    elif entity_type == "knight":
        episode_time = time.time() - (time.time() - starting_time) + 933

    background = sprites_load.background

    entity1_lives = int(save[0])
    entity2_lives = int(save[1])
    entity3_lives = int(save[2])

    entity4_lives = int(save[3])
    entity5_lives = int(save[4])
    entity6_lives = int(save[5])

    remained_lives = int(save[14])

while True:
    if not first_start:
        if quest_one:
            if entity_type == "orc":
                original_lives = 2

            if entity_type == "boss1":
                original_lives = 10

            if starting_time == 0:
                starting_time = time.time() - 3
                episode_time = time.time() - 3
            if entity_type == "dino":
                background = sprites_load.jungle_background

            if entity_type == "orc":
                background = sprites_load.orc_background

            if entity_type == "knight":
                background = sprites_load.castle_background

            if entity_type == "boss1":
                background = sprites_load.hell_background

            shp_str = str(shotgun_pistol_ammo)
            grn_str = str(grenades_left)
            pygame.mouse.set_visible(False)
            if remained_lives <= 0:
                time.sleep(1)
                first_start = True

                starting_time = 0

                bullets_left = 10
                grenades_left = 0

                walk_right = False
                walk_left = False

                walk_index = 0

                level_up_time = 0

                characterx = 1440 / 2
                charactery = 710

                life_loss = 0

                grenade_time_start = 0

                facing_left = False
                facing_right = True

                fired_left = False
                fired_right = False

                grenade_threw = False

                fired_time = 0

                target = None

                entity1x = -100

                entity3x = -300
                entity5x = -500

                shotgun_pistol_ammo = 3
                last_given_spammo = 0

                entity2x = info.winfo_screenwidth()

                entity4x = info.winfo_screenwidth() + 200
                entity6x = info.winfo_screenwidth() + 400

                enemy_y = info.winfo_screenheight() - 190

                zombie_anim_index = 0

                shoot = False

                gun = 1

                original_lives = 1

                last_given_bullet = 0
                last_given_grenade = 0

                grenadex = 1440 / 2
                grenadey = 0

                first = True

                first_time_sound = True

                rifle_ammo = 3

                episode_time = starting_time

                entity_type = "zombie"

                background = sprites_load.background

                remained_lives = 3

                entity1_lives = original_lives
                entity2_lives = original_lives
                entity3_lives = original_lives

                entity4_lives = original_lives
                entity5_lives = original_lives
                entity6_lives = original_lives

                meteor1y = -100
                meteor2y = -200
                meteor3y = -300
                meteor4y = -400
                meteor5y = -500

            if meteor1y > info.winfo_screenwidth() - 150:
                meteor1y = -100
                entity1x = random.randint(100, 300)
            if meteor2y > info.winfo_screenwidth() - 150:
                meteor2y = -200
                entity2x = random.randint(200, 500)

            if meteor3y > info.winfo_screenwidth() - 150:
                meteor3y = -300
                entity3x = random.randint(400, 750)

            if meteor4y > info.winfo_screenwidth() - 150:
                meteor4y = -400
                entity4x = random.randint(650, 1100)
            if meteor5y > info.winfo_screenwidth() - 150:
                meteor5y = -500
                entity5x = random.randint(650, 900)

            if entity1_lives <= 0:
                if not entity_type == "boss1":
                    if gun == 1:
                        entity1x = -400
                    elif gun == 2:
                        entity1x = -400
                    elif gun == 3:
                        entity1x = -400

                entity1_lives = original_lives

            if entity3_lives <= 0:
                if not entity_type == "boss1":
                    if gun == 1:
                        entity3x = -400
                    elif gun == 2:
                        entity3x = -600
                    elif gun == 3:
                        entity3x = -400

                entity3_lives = original_lives

            if entity5_lives <= 0:
                if not entity_type == "boss1":
                    if gun == 1:
                        entity5x = -400
                    elif gun == 2:
                        entity5x = -800
                    elif gun == 3:
                        entity5x = -400
                entity5_lives = original_lives

            if entity2_lives <= 0:
                if not entity_type == "boss1":
                    if gun == 1:
                        entity2x = info.winfo_screenwidth() + 400
                    elif gun == 2:
                        entity2x = info.winfo_screenwidth() + 200
                    elif gun == 3:
                        entity2x = info.winfo_screenwidth() + 400
                entity2_lives = original_lives

            if entity4_lives <= 0:
                if not entity_type == "boss1":
                    if gun == 1:
                        entity4x = info.winfo_screenwidth() + 400
                    elif gun == 2:
                        entity4x = info.winfo_screenwidth() + 400
                    elif gun == 3:
                        entity4x = info.winfo_screenwidth() + 400
                entity4_lives = original_lives

            if entity6_lives <= 0:
                if not entity_type == "boss1":
                    if gun == 1:
                        entity6x = info.winfo_screenwidth() + 400
                    elif gun == 2:
                        entity6x = info.winfo_screenwidth() + 600
                    elif gun == 3:
                        entity6x = info.winfo_screenwidth() + 400
                entity6_lives = original_lives

            if int((time.time() - starting_time - 3)) % 50 == 0 and not int(time.time() - starting_time - 3) == 0:
                if int(time.time()) - int(last_given_bullet) > 1:
                    if not entity_type == "boss1":
                        bullets_left += 6
                    if entity_type == "boss1":
                        bullets_left += 4
                    last_given_bullet = int(time.time())

            if int((time.time() - starting_time - 3)) % 75 == 0 and not int(time.time() - starting_time - 3) == 0:
                if int(time.time()) - int(last_given_grenade) > 1:
                    grenades_left += 1
                    last_given_grenade = int(time.time())

            if int((time.time() - starting_time - 3)) % 60 == 0 and int(time.time() - starting_time - 3) >= 600:
                if int(time.time()) - int(last_given_spammo) > 1:
                    shotgun_pistol_ammo += 2
                    last_given_spammo = int(time.time())

            if int((time.time() - starting_time - 3)) % 40 == 0 and int(time.time() - starting_time - 3) >= 930:
                if int(time.time()) - int(last_give_dynamite) > 1:
                    dynamites_left += 1
                    last_give_dynamite = int(time.time())

            if entity_type == "zombie":
                entity1x = entity1x + 3
                entity3x = entity3x + 3
                entity5x = entity5x + 3

                entity2x = entity2x - 3
                entity4x = entity4x - 3
                entity6x = entity6x - 3

            elif entity_type == "dino":
                entity1x = entity1x + 5
                entity3x = entity3x + 5
                entity5x = entity5x + 5

                entity2x = entity2x - 5
                entity4x = entity4x - 5
                entity6x = entity6x - 5

            elif entity_type == "orc":
                entity1x = entity1x + 3
                entity3x = entity3x + 3
                entity5x = entity5x + 3

                entity2x = entity2x - 3
                entity4x = entity4x - 3
                entity6x = entity6x - 3

            elif entity_type == "knight":
                entity1x = entity1x + 5
                entity3x = entity3x + 5
                entity5x = entity5x + 5

                entity2x = entity2x - 5
                entity4x = entity4x - 5
                entity6x = entity6x - 5
            elif entity_type == "boss1":
                entity6x = info.winfo_screenwidth() - 400

            time_passed = font.render(f"Time: {int(time.time() - starting_time - 3)}", True, (0, 0, 0))

            zombie_anim_index += 1

            if entity_type == "boss1":
                if characterx + 150 > entity6x:
                    characterx -= 6

            if entity_type == "boss1":
                meteor1y += 20
            if entity_type == "boss1":
                meteor2y += 20
            if entity_type == "boss1":
                meteor3y += 20
            if entity_type == "boss1":
                meteor4y += 20
            if entity_type == "boss1":
                meteor5y += 20
            if entity_type == "boss1":
                grenades_left = 0
                dynamites_left = 0

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if bullets_left > 0:
                        if gun == 1:
                            if not entity_type == "boss1":
                                fired_time = time.time()
                                bullets_left = bullets_left - 1

                                if pygame.mouse.get_pos()[0] < characterx:
                                    target = (0, pygame.mouse.get_pos()[1])
                                    facing_left = True
                                    facing_right = False
                                    fired_left = True
                                if pygame.mouse.get_pos()[0] > characterx:
                                    target = (1440, pygame.mouse.get_pos()[1])
                                    facing_left = False
                                    facing_right = True
                                    fired_right = True

                            if entity_type == "boss1":
                                if pygame.mouse.get_pos()[0] > characterx and not walk_left:
                                    entity6_lives -= 1
                                    bullets_left -= 1
                                    facing_right = True
                                    walk_right = False
                                    screen.fill((0, 0, 0))
                                    pygame.mixer.music.load("sounds/hit_target.mp3")
                                    pygame.mixer.music.play(1)

                    if gun == 2:
                        if not entity_type == "boss1":
                            if rifle_ammo > 0:
                                rifle_ammo -= 1
                                if pygame.mouse.get_pos()[0] < characterx:
                                    facing_left = True
                                    facing_right = False

                                    if not entity_type == "knight":
                                        entity1_lives -= 1
                                        entity3_lives -= 1
                                        entity5_lives -= 1

                                    characterx += 50

                                if pygame.mouse.get_pos()[0] > characterx:
                                    facing_right = True
                                    facing_left = False

                                    if not entity_type == "knight":
                                        entity2_lives -= 1
                                        entity4_lives -= 1
                                        entity6_lives -= 1

                                    characterx -= 50

                                pygame.mixer.music.load("sounds/rifle_sound.mp3")
                                pygame.mixer.music.play(1)

                    if gun == 3:
                        if shotgun_pistol_ammo > 0:
                            if not entity_type == "boss1":
                                shotgun_pistol_ammo -= 1
                                if pygame.mouse.get_pos()[0] < characterx:
                                    facing_left = True
                                    facing_right = False

                                    if entity1x > entity3x and entity3x > entity5x:
                                        entity1_lives -= 2

                                    elif entity1x < entity3x and entity3x > entity5x:
                                        entity3_lives -= 2

                                    else:
                                        entity5_lives -= 2

                                if pygame.mouse.get_pos()[0] > characterx:

                                    facing_left = False
                                    facing_right = True

                                    if entity2x < entity4x and entity4x < entity6x:
                                        entity2_lives -= 2

                                    elif entity2x > entity4x and entity4x < entity6x:
                                        entity4_lives -= 2

                                    else:
                                        entity6_lives -= 2

                                pygame.mixer.music.load("sounds/spsound.mp3")
                                pygame.mixer.music.play(1)
                            if entity_type == "boss1":
                                if pygame.mouse.get_pos()[0] > characterx and not walk_left:
                                    walk_left = False
                                    walk_right = False
                                    facing_right = True
                                    entity6_lives -= 2
                                    shotgun_pistol_ammo -= 1
                                    pygame.mixer.music.load("sounds/spsound.mp3")
                                    pygame.mixer.music.play(1)

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_d:
                        facing_left = False
                        facing_right = True

                        walk_right = True

                    if event.key == pygame.K_a:
                        facing_left = True
                        facing_right = False

                        walk_left = True

                    if event.key == pygame.K_w:
                        if dynamites_left >= 1:

                            pygame.mixer.music.load("sounds/dynamite_explosion.mp3")
                            pygame.mixer.music.play(1)

                            dynamites_left -= 1
                            dynamite_threw = True
                            thrown_time = time.time()

                            if entity2x < entity4x and entity4x < entity6x:
                                entity2_lives -= 2

                            elif entity2x > entity4x and entity4x < entity6x:
                                entity4_lives -= 2

                            else:
                                entity6_lives -= 2

                    if event.key == pygame.K_e:
                        if grenades_left >= 1:
                            grenades_left -= 1

                            grenade_time_start = time.time()

                            grenade_threw = True

                    if event.key == pygame.K_RIGHT:
                        if time.time() - starting_time - 3 >= 305:
                            if gun == 1:
                                gun = 2
                            elif gun == 2:
                                if time.time() - starting_time - 3 >= 610:
                                    gun = 3

                    if event.key == pygame.K_LEFT:
                        if gun == 2:
                            gun = 1
                        elif gun == 3:
                            gun = 2

                    if event.key == pygame.K_q:
                        f = open("save.txt", "w+")
                        f.write(f'''{entity1_lives} {entity2_lives} {entity3_lives} {entity4_lives} {entity5_lives} 
                                    {entity6_lives} {entity1x} {entity2x} {entity3x} {entity4x}  {entity5x}  {entity6x} 
                                    {time.time() - starting_time} {characterx} {remained_lives} {bullets_left} 
                                    {rifle_ammo} {shp_str} {grn_str} {entity_type} {dynamites_left} {freeze_left}
''')
                        f.close()

                        mon = open("money.txt", "w+")

                        mon.write(str(money))

                        mon.close()

                        pygame.quit()
                        sys.exit()
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_d:
                        walk_right = False

                    if event.key == pygame.K_a:
                        walk_left = False

            if characterx >= info.winfo_screenwidth() - 100:
                characterx -= 6

            if characterx <= 0:
                characterx += 6

            if walk_right:
                characterx += 6
                walk_index += 1

            if walk_left:
                characterx -= 6
                walk_index += 1

            if not walk_right and not walk_left:
                walk_index = 0

            timing = pygame.time.Clock()
            timing.tick(30)

            if positionx + info.winfo_screenwidth() < info.winfo_screenwidth():
                positionx += 1
            elif positionx + info.winfo_screenwidth() < info.winfo_screenwidth():
                positionx -= 1

            screen.blit(background, (positionx, 0))

            show_enemies.show(screen, zombie_anim_index, entity1x, entity2x, entity3x,
                              entity4x, entity5x, entity6x, entity_type, meteor1y, meteor2y, meteor3y, meteor4y,
                              meteor5y, missile1x, missile2x)

            if not grenadey >= 800:
                if facing_right:
                    if gun == 1:
                        screen.blit(sprites_load.character_animations_right[walk_index %
                                                                            len(sprites_load.character_animations_right)],
                                    (characterx, charactery))
                    if gun == 2:
                        screen.blit(sprites_load.rifle_animation_right[walk_index %
                                                                       len(sprites_load.rifle_animation_right)],
                                    (characterx, charactery))

                    if gun == 3:
                        screen.blit(sprites_load.shotgun_pistol_animations_right
                                    [walk_index % len(sprites_load.shotgun_pistol_animations_right)],
                                    (characterx, charactery))
                if facing_left:
                    if gun == 1:
                        screen.blit(sprites_load.character_animations_left[walk_index %
                                                                           len(sprites_load.character_animations_right)],
                                    (characterx, charactery))
                    if gun == 2:
                        screen.blit(sprites_load.rifle_animation_left[walk_index % len(sprites_load.rifle_animation_left)],
                                    (characterx, charactery))

                    if gun == 3:
                        screen.blit(sprites_load.shotgun_pistol_animations_left
                                    [walk_index % len(sprites_load.shotgun_pistol_animations_left)],
                                    (characterx, charactery))

            if gun == 1:
                for i in range(bullets_left):
                    screen.blit(sprites_load.bullet, (i * 10 + 10, 10))

            for i in range(int(grenades_left)):
                screen.blit(sprites_load.grenade, (info.winfo_screenwidth() - (i * 50) - 120 + 20, 60))

            if gun == 2:
                for i in range(rifle_ammo):
                    screen.blit(sprites_load.rifle_ammo, (i * 30, -10))

            if gun == 3:
                for i in range(shotgun_pistol_ammo):
                    screen.blit(sprites_load.spammo, (i * 10 + 15, 40))

            for i in range(dynamites_left):
                screen.blit(sprites_load.dynamite, (i * 20, 100))

            if gun == 1:
                screen.blit(sprites_load.pistol, (700, 60))

            if gun == 2:
                screen.blit(sprites_load.rifle, (700, 60))

            if gun == 3:
                screen.blit(sprites_load.s_pistol, (700, 60))

            if entity_type == "zombie" or entity_type == "orc" or entity_type == "knight":
                enemy_y = info.winfo_screenheight() - 190
            if entity_type == "dino":
                enemy_y = info.winfo_screenheight() - 250

            if fired_right:
                if target[1] > enemy_y:
                    if not shoot:
                            if entity2x < info.winfo_screenwidth() or entity4x < info.winfo_screenwidth() or \
                                    entity6x < info.winfo_screenwidth():
                                if not entity_type == "knight":
                                    pygame.mixer.music.load("sounds/hit_target.mp3")
                                    pygame.mixer.music.play(1)
                                    if random.randint(1, 3) == 2:
                                        bullets_left = bullets_left + 1

                                    if random.randint(1, 6) == 3:
                                        rifle_ammo += 1

                                    shoot = True

                                    if entity2x < entity4x and entity4x < entity6x:
                                        entity2_lives -= 1

                                    elif entity2x > entity4x and entity4x < entity6x:
                                        entity4_lives -= 1

                                    else:
                                        entity6_lives -= 1
                                else:
                                    if first:
                                        pygame.mixer.music.load("sounds/firearm.mp3")
                                        pygame.mixer.music.play(1)
                                        first = False
                            if entity_type == "knight":
                                if target[1] > enemy_y + 50:
                                    if target[1] < enemy_y + 100:
                                        pygame.mixer.music.load("sounds/hit_target.mp3")
                                        pygame.mixer.music.play(1)
                                        if random.randint(1, 3) == 2:
                                            bullets_left = bullets_left + 1

                                        if random.randint(1, 6) == 3:
                                            rifle_ammo += 1

                                        shoot = True

                                        if entity2x < entity4x and entity4x < entity6x:
                                            entity2_lives -= 1

                                        elif entity2x > entity4x and entity4x < entity6x:
                                            entity4_lives -= 1

                                        else:
                                            entity6_lives -= 1
                                    else:
                                        if first:
                                            pygame.mixer.music.load("sounds/firearm.mp3")
                                            pygame.mixer.music.play(1)
                                            first = False
                else:
                    if first:
                        pygame.mixer.music.load("sounds/firearm.mp3")
                        pygame.mixer.music.play(1)
                        first = False

                if time.time() - fired_time > 0.3:
                    first = True
                    shoot = False
                    fired_right = False
                pygame.draw.line(screen, (0, 0, 0), (characterx + 100, charactery + 30), target, 2)

            # pygame.draw.rect(screen, (0, 0, 255), (685, 0, 115, 50))
            screen.blit(time_passed, (700, 10))

            if fired_left:
                if not shoot:
                    if target[1] > enemy_y:
                        if entity1x > -100 or entity3x > -100 or entity5x > -100:
                            if not shoot:
                                if not entity_type == "knight":
                                    pygame.mixer.music.load("sounds/hit_target.mp3")
                                    pygame.mixer.music.play(1)
                                    if random.randint(1, 3) == 2:
                                        bullets_left = bullets_left + 1

                                    if random.randint(1, 6) == 3:
                                        rifle_ammo += 1

                                    shoot = True

                                    if entity1x > entity3x and entity3x > entity5x:
                                        entity1_lives -= 1

                                    elif entity1x < entity3x and entity3x > entity5x:
                                        entity3_lives -= 1

                                    else:
                                        entity5_lives -= 1
                                if entity_type == "knight":
                                    if target[1] > enemy_y + 50:
                                        if target[1] < enemy_y + 100:
                                            pygame.mixer.music.load("sounds/hit_target.mp3")
                                            pygame.mixer.music.play(1)
                                            if random.randint(1, 3) == 2:
                                                bullets_left = bullets_left + 1

                                            if random.randint(1, 6) == 3:
                                                rifle_ammo += 1

                                            shoot = True

                                            if entity1x > entity3x and entity3x > entity5x:
                                                entity1_lives -= 1

                                            elif entity1x < entity3x and entity3x > entity5x:
                                                entity3_lives -= 1

                                            else:
                                                entity5_lives -= 1
                        else:
                            if first:
                                pygame.mixer.music.load("sounds/firearm.mp3")
                                pygame.mixer.music.play(1)
                                first = False

                    else:
                        if first:
                            pygame.mixer.music.load("sounds/firearm.mp3")
                            pygame.mixer.music.play(1)
                            first = False
                if time.time() - fired_time > 0.3:
                    shoot = False
                    fired_left = False
                    first = True
                pygame.draw.line(screen, (0, 0, 0), (characterx, charactery + 30), target, 2)

            if grenade_threw:
                screen.blit(sprites_load.grenade, (grenadex, grenadey))
                grenadey += 25

                if grenadey >= 800:
                    if not entity_type == "boss1":
                        if first_time_sound:
                            pygame.mixer.music.load("sounds/explosion.mp3")
                            pygame.mixer.music.play(1)
                            first_time_sound = False

                        entity1x = -300
                        entity2x = info.winfo_screenwidth() + 600
                        entity3x = -400

                        entity4x = info.winfo_screenwidth() + 800
                        entity5x = -600
                        entity6x = info.winfo_screenwidth() + 1000

                        screen.blit(sprites_load.explosion, (0, 0))

                        if not pygame.mixer.get_busy() and int(time.time() - grenade_time_start) >= 8:
                            grenadey = 0
                            grenade_threw = False
                            first_time_sound = True

            if not entity_type == "boss1":
                if entity1x >= characterx - 120 or entity3x >= characterx - 120 or entity5x >= characterx - 120:
                    entity1x = -200
                    entity3x = -400
                    entity5x = -600

                    entity2x = info.winfo_screenwidth()
                    entity4x = info.winfo_screenwidth() + 200
                    entity6x = info.winfo_screenwidth() + 400

                    if entity_type == "zombie" or entity_type == "knight" or entity_type == "orc":
                        remained_lives -= 1
                    elif entity_type == "dino":
                        remained_lives -= 2

                    life_loss = time.time()

                if entity2x <= characterx + 130 or entity4x <= characterx + 130 or entity6x <= characterx + 130:
                    entity2x = info.winfo_screenwidth()
                    entity4x = info.winfo_screenwidth() + 200
                    entity6x = info.winfo_screenwidth() + 400

                    entity1x = -200
                    entity3x = -400
                    entity5x = -600

                    if entity_type == "zombie" or entity_type == "knight" or entity_type == "orc":
                        remained_lives -= 1
                    elif entity_type == "dino":
                        remained_lives -= 2

                    characterx = 1440 / 2

                    life_loss = time.time()

            if entity_type == "boss1":
                if meteor1y + 150 > charactery:
                    if meteor1y < charactery + 150:
                        if entity1x > characterx and entity1x < characterx + 150:
                            remained_lives = 0
                if meteor2y + 150 > charactery:
                    if meteor2y < charactery + 150:
                        if entity2x > characterx and entity2x < characterx + 150:
                            remained_lives = 0
                if meteor3y + 150 > charactery:
                    if meteor3y < charactery + 150:
                        if entity3x > characterx and entity3x < characterx + 150:
                            remained_lives = 0
                if meteor4y + 150 > charactery:
                    if meteor4y < charactery + 150:
                        if entity4x > characterx and entity4x < characterx + 150:
                            remained_lives = 0
                if meteor5y + 150 > charactery:
                    if meteor5y < charactery + 150:
                        if entity5x > characterx and entity5x < characterx + 150:
                            remained_lives = 0

            screen.blit(sprites_load.cursor, (pygame.mouse.get_pos()[0] - 25, pygame.mouse.get_pos()[1] - 25))

            if not time.time() - life_loss >= 1:
                screen.fill((0, 0, 0))

            for i in range(remained_lives):
                screen.blit(sprites_load.heart, (i * 30 + info.winfo_screenwidth() - 200, 0))

            if time.time() - episode_time >= 300 and not entity_type == "boss1":
                if not entity_type == "boss":
                    level_up_time = time.time()
                    if entity_type == "zombie":
                        retreat = font.render("Zombies are retreating || You are ready for the dinosaurs now",
                                              True, (255, 255, 255))
                    if entity_type == "dino":
                        retreat = font.render("Dinosaurs are retreating || You are ready for the orcs now",
                                              True, (255, 255, 255))
                    if entity_type == "orc":
                        retreat = font.render("Orcs are retreating || You are ready for the knights now",
                                              True, (255, 255, 255))
                    if entity_type == "knight":
                        retreat = font.render("Boss Fight!",
                                              True, (255, 255, 255))
                    screen.blit(retreat, (0, 425))

                    charactery -= 10

                    entity1x -= 10
                    entity3x -= 10
                    entity5x -= 10

                    entity2x += 10
                    entity4x += 10
                    entity6x += 10

            if time.time() - level_up_time <= 2 and charactery == 710:

                f = open("save.txt", "w+")
                f.write(f'''{entity1_lives} {entity2_lives} {entity3_lives} {entity4_lives} {entity5_lives} 
                            {entity6_lives} {entity1x} {entity2x} {entity3x} {entity4x}  {entity5x}  {entity6x} 
                            {time.time() - starting_time} {characterx} {remained_lives} {bullets_left} 
                            {rifle_ammo} {shp_str} {grn_str} {entity_type} {dynamites_left} {freeze_left}
                ''')

                f.close()

                mon = open("money.txt", "w+")

                mon.write(str(money))

                mon.close()

                if not entity_type == "boss1":
                    entity1x = -300
                    entity2x = info.winfo_screenwidth() + 600
                    entity3x = -400

                    entity4x = info.winfo_screenwidth() + 800
                    entity5x = -600
                    entity6x = info.winfo_screenwidth() + 400

                elif entity_type == "boss1":
                    entity1x = 100
                    entity2x = 300
                    entity3 = 500
                    entity4x = 700
                    entity5x = 900

                screen.fill((0, 0, 0))

                if entity_type == "dino":
                    new_weapon = bigger_font.render("New Weapon Unlocked:", True, (255, 255, 255))
                    new_weapon_2 = bigger_font.render("Press -> to use", True, (255, 255, 255))
                    level_up_text = bigger_font.render("Level Up!", True, (255, 255, 255))
                    screen.blit(level_up_text, (100, 400))
                    screen.blit(new_weapon, (100, 450))
                    screen.blit(sprites_load.level_up_version_rifle, (625, 400))
                    screen.blit(new_weapon_2, (100, 500))

                if entity_type == "orc":
                    new_weapon = bigger_font.render("New Weapon Unlocked:", True, (255, 255, 255))
                    new_weapon_2 = bigger_font.render("Press -> to use", True, (255, 255, 255))
                    level_up_text = bigger_font.render("Level Up!", True, (255, 255, 255))
                    screen.blit(level_up_text, (info.winfo_screenwidth() - 1400, 400))
                    screen.blit(new_weapon, (info.winfo_screenwidth() - 1400, 450))
                    screen.blit(sprites_load.level_up_version_spistol, (info.winfo_screenwidth() - 900, 450))
                    screen.blit(new_weapon_2, (info.winfo_screenwidth() - 1400, 500))

                if entity_type == "knight":
                    new_weapon = bigger_font.render("New Gadget Unlocked:", True, (255, 255, 255))
                    new_weapon_2 = bigger_font.render("Press W to use", True, (255, 255, 255))
                    level_up_text = bigger_font.render("Level Up!", True, (255, 255, 255))
                    screen.blit(level_up_text, (info.winfo_screenwidth() - 1400, 350))
                    screen.blit(new_weapon, (info.winfo_screenwidth() - 1400, 425))
                    screen.blit(sprites_load.level_up_version_dynamite, (info.winfo_screenwidth() - 900, 400))
                    screen.blit(new_weapon_2, (info.winfo_screenwidth() - 1400, 500))

                if entity_type == "boss1":
                    level_up_text = bigger_font.render("The First Boss Fight!", True, (255, 255, 255))
                    screen.blit(level_up_text, (info.winfo_screenwidth() - 1400, 350))

            if charactery <= -150:
                charactery = 710
                episode_time = time.time() + 3
                if entity_type == "zombie":
                    entity_type = "dino"
                elif entity_type == "dino":
                    entity_type = "orc"
                elif entity_type == "orc":
                    entity_type = "knight"
                elif entity_type == "knight":
                    entity_type = "boss1"

                if entity_type == "orc":
                    original_lives = 2
                elif entity_type == "knight":
                    original_lives = 1
                elif entity_type == "boss1":
                    original_lives = 10

                    entity6x = info.winfo_screenwidth() - 400
                    entity1x = random.randint(0, 300)
                    entity2x = random.randint(150, 500)
                    entity3 = random.randint(300, 700)
                    entity4x = random.randint(600, 800)
                    entity5x = random.randint(650, 950)

                entity1_lives = original_lives
                entity2_lives = original_lives
                entity3_lives = original_lives

                entity4_lives = original_lives
                entity5_lives = original_lives
                entity6_lives = original_lives

            if dynamite_threw:
                if time.time() - thrown_time >= 0.5:
                    if entity1x > entity3x and entity3x > entity5x:
                        entity1_lives -= 2

                    elif entity1x < entity3x and entity3x > entity5x:
                        entity3_lives -= 2

                    else:
                        entity5_lives -= 2
                    dynamite_threw = False

                screen.blit(sprites_load.dynamite_explosion, (characterx - 250, charactery - 200))

            if entity6_lives <= 0:
                if entity_type == "boss1":
                    if not ending_time:
                        ending_time = time.time()
                    if time.time() - ending_time < 3:
                        screen.fill((0, 0, 0))
                        won = bigger_font.render("Quest Over: You Won", True, (255, 255, 255))
                        screen.blit(won, (100, 450))

                        try:
                            if os.path.exists("save.txt"):
                                os.remove("save.txt")

                                characterx = 1200
                                quest_one = False

                            pygame.mouse.set_visible(True)

                            file = open("level_save", "w+")
                            file.write("quest 2")
                            file.close()

                            money += 120

                            mon = open("money.txt", "w+")
                            mon.write(str(money))
                            mon.close()

                        except Exception as e:
                            print(e)

        elif quest_two:

            if entity_type == "zombie":
                entity_type = "demon"
            if entity_type == "demon":
                original_lives = 2
            if entity_type == "jinn":
                original_lives = 1

            if entity1_lives > original_lives:
                entity1_lives = original_lives

            if entity2_lives > original_lives:
                entity2_lives = original_lives

            if entity3_lives > original_lives:
                entity3_lives = original_lives

            if entity4_lives > original_lives:
                entity4_lives = original_lives

            if entity5_lives > original_lives:
                entity5_lives = original_lives

            if entity6_lives > original_lives:
                entity6_lives = original_lives

            if starting_time == 0:
                starting_time = time.time() - 3
                episode_time = time.time() - 3
            if entity_type == "demon":
                background = sprites_load.demon_background

            if entity_type == "jinn":
                background = sprites_load.jinn_background

            if entity_type == "lizard":
                background = sprites_load.lizard_background

            shp_str = str(shotgun_pistol_ammo)
            grn_str = str(grenades_left)
            pygame.mouse.set_visible(False)
            if remained_lives <= 0:
                time.sleep(1)
                first_start = True

                starting_time = 0

                bullets_left = 10
                grenades_left = 0

                walk_right = False
                walk_left = False

                walk_index = 0

                level_up_time = 0

                characterx = 1440 / 2
                charactery = 710

                life_loss = 0

                grenade_time_start = 0

                facing_left = False
                facing_right = True

                fired_left = False
                fired_right = False

                grenade_threw = False

                fired_time = 0

                target = None

                entity1x = -100

                entity3x = -300
                entity5x = -500

                shotgun_pistol_ammo = 3
                last_given_spammo = 0

                entity2x = info.winfo_screenwidth()

                entity4x = info.winfo_screenwidth() + 200
                entity6x = info.winfo_screenwidth() + 400

                enemy_y = info.winfo_screenheight() - 190

                zombie_anim_index = 0

                shoot = False

                gun = 1

                original_lives = 2

                last_given_bullet = 0
                last_given_grenade = 0

                grenadex = 1440 / 2
                grenadey = 0

                first = True

                first_time_sound = True

                rifle_ammo = 3

                episode_time = time.time()

                entity_type = "demon"

                background = sprites_load.demon_background

                remained_lives = 3

                entity1_lives = original_lives
                entity2_lives = original_lives
                entity3_lives = original_lives

                entity4_lives = original_lives
                entity5_lives = original_lives
                entity6_lives = original_lives

            if entity1_lives <= 0:
                if gun == 1:
                    entity1x = -400
                elif gun == 2:
                    entity1x = -400
                elif gun == 3:
                    entity1x = -400

                entity1_lives = original_lives

            if entity3_lives <= 0:
                if gun == 1:
                    entity3x = -400
                elif gun == 2:
                    entity3x = -600
                elif gun == 3:
                    entity3x = -400

                entity3_lives = original_lives

            if entity5_lives <= 0:
                if gun == 1:
                    entity5x = -400
                elif gun == 2:
                    entity5x = -800
                elif gun == 3:
                    entity5x = -400

                entity5_lives = original_lives

            if entity2_lives <= 0:
                if gun == 1:
                    entity2x = info.winfo_screenwidth() + 400
                elif gun == 2:
                    entity2x = info.winfo_screenwidth() + 200
                elif gun == 3:
                    entity2x = info.winfo_screenwidth() + 400

                entity2_lives = original_lives

            if entity4_lives <= 0:
                if gun == 1:
                    entity4x = info.winfo_screenwidth() + 400
                elif gun == 2:
                    entity4x = info.winfo_screenwidth() + 400
                elif gun == 3:
                    entity4x = info.winfo_screenwidth() + 400
                entity4_lives = original_lives

            if entity6_lives <= 0:
                if gun == 1:
                    entity6x = info.winfo_screenwidth() + 400
                elif gun == 2:
                    entity6x = info.winfo_screenwidth() + 600
                elif gun == 3:
                    entity6x = info.winfo_screenwidth() + 400

                entity6_lives = original_lives

            if int((time.time() - starting_time - 3)) % 50 == 0 and not int(time.time() - starting_time - 3) == 0:
                if int(time.time()) - int(last_given_bullet) > 1:
                    bullets_left += 6
                    last_given_bullet = int(time.time())

            if int((time.time() - starting_time - 3)) % 75 == 0 and not int(time.time() - starting_time - 3) == 0:
                if int(time.time()) - int(last_given_grenade) > 1:
                    grenades_left += 1
                    last_given_grenade = int(time.time())

            if int((time.time() - starting_time - 3)) % 60 == 0:
                if int(time.time()) - int(last_given_spammo) > 1:
                    shotgun_pistol_ammo += 2
                    last_given_spammo = int(time.time())

            if int((time.time() - starting_time - 3)) % 40 == 0:
                if int(time.time()) - int(last_give_dynamite) > 1:
                    dynamites_left += 1
                    last_give_dynamite = int(time.time())

            if int((time.time() - starting_time - 3)) % 100 == 0:
                if int(time.time()) - int(last_give_freeze) > 1:
                    if not entity_type == "demon" and not entity_type == "jinn":
                        freeze_left += 1
                        last_give_freeze = int(time.time())

            if time.time() - frozen_time > 10:
                frozen = False

            if not frozen:
                if entity_type == "demon" or entity_type == "jinn":
                    entity1x = entity1x + 5
                    entity3x = entity3x + 5
                    entity5x = entity5x + 5

                    entity2x = entity2x - 5
                    entity4x = entity4x - 5
                    entity6x = entity6x - 5

                elif entity_type == "lizard":
                    entity1x = entity1x + 8
                    entity3x = entity3x + 8
                    entity5x = entity5x + 8

                    entity2x = entity2x - 8
                    entity4x = entity4x - 8
                    entity6x = entity6x - 8

            time_passed = font.render(f"Time: {int(time.time() - starting_time - 3)}", True, (0, 0, 0))

            if not frozen:
                zombie_anim_index += 1

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if bullets_left > 0:
                        if gun == 1:
                            fired_time = time.time()
                            bullets_left = bullets_left - 1

                            if pygame.mouse.get_pos()[0] < characterx:
                                target = (0, pygame.mouse.get_pos()[1])
                                facing_left = True
                                facing_right = False
                                fired_left = True
                            if pygame.mouse.get_pos()[0] > characterx:
                                target = (1440, pygame.mouse.get_pos()[1])
                                facing_left = False
                                facing_right = True
                                fired_right = True

                    if gun == 2:
                        if rifle_ammo > 0:
                            rifle_ammo -= 1
                            if pygame.mouse.get_pos()[0] < characterx:
                                facing_left = True
                                facing_right = False

                                entity1_lives -= 1
                                entity3_lives -= 1
                                entity5_lives -= 1

                                characterx += 50

                            if pygame.mouse.get_pos()[0] > characterx:
                                facing_right = True
                                facing_left = False

                                entity2_lives -= 1
                                entity4_lives -= 1
                                entity6_lives -= 1

                                characterx -= 50

                        pygame.mixer.music.load("sounds/rifle_sound.mp3")
                        pygame.mixer.music.play(1)

                    if gun == 3:
                        if shotgun_pistol_ammo > 0:
                            shotgun_pistol_ammo -= 1
                            if pygame.mouse.get_pos()[0] < characterx:
                                facing_left = True
                                facing_right = False

                                if entity1x > entity3x and entity3x > entity5x:
                                    entity1_lives -= 2

                                elif entity1x < entity3x and entity3x > entity5x:
                                    entity3_lives -= 2

                                else:
                                    entity5_lives -= 2

                            if pygame.mouse.get_pos()[0] > characterx:

                                facing_left = False
                                facing_right = True

                                if entity2x < entity4x and entity4x < entity6x:
                                    entity2_lives -= 2

                                elif entity2x > entity4x and entity4x < entity6x:
                                        entity4_lives -= 2

                                else:
                                    entity6_lives -= 2

                            pygame.mixer.music.load("sounds/spsound.mp3")
                            pygame.mixer.music.play(1)

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_d:
                            facing_left = False
                            facing_right = True

                            walk_right = True

                    if event.key == pygame.K_a:
                            facing_left = True
                            facing_right = False

                            walk_left = True

                    if event.key == pygame.K_w:
                        if dynamites_left >= 1:

                            pygame.mixer.music.load("sounds/dynamite_explosion.mp3")
                            pygame.mixer.music.play(1)

                            dynamites_left -= 1
                            dynamite_threw = True
                            thrown_time = time.time()

                            if entity2x < entity4x and entity4x < entity6x:
                                entity2_lives -= 2

                            elif entity2x > entity4x and entity4x < entity6x:
                                entity4_lives -= 2

                            else:
                                entity6_lives -= 2

                    if event.key == pygame.K_e:
                        if grenades_left >= 1:
                            grenades_left -= 1

                            grenade_time_start = time.time()

                            grenade_threw = True

                    if event.key == pygame.K_r:
                        if freeze_left > 0:
                            freeze_left -= 1
                            frozen = True
                            frozen_time = time.time()

                    if event.key == pygame.K_RIGHT:
                        if gun == 1:
                            gun = 2
                        elif gun == 2:
                            gun = 3

                    if event.key == pygame.K_LEFT:
                        if gun == 2:
                            gun = 1
                        elif gun == 3:
                            gun = 2

                    if event.key == pygame.K_SPACE:
                        if not entity_type == "demon":
                            if not jumping and not falling:
                                jumping = True

                    if event.key == pygame.K_q:
                        f = open("save.txt", "w+")
                        f.write(f'''{entity1_lives} {entity2_lives} {entity3_lives} {entity4_lives} {entity5_lives} 
                                    {entity6_lives} {entity1x} {entity2x} {entity3x} {entity4x}  {entity5x}  {entity6x} 
                                    {time.time() - starting_time} {characterx} {remained_lives} {bullets_left} 
                                    {rifle_ammo} {shp_str} {grn_str} {entity_type} {dynamites_left} {freeze_left}''')
                        f.close()

                        mon = open("money.txt", "w+")

                        mon.write(str(money))

                        mon.close()

                        pygame.quit()
                        sys.exit()
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_d:
                        walk_right = False

                    if event.key == pygame.K_a:
                        walk_left = False

            if characterx >= info.winfo_screenwidth() - 100:
                characterx -= 6

            if characterx <= 0:
                characterx += 6

            if walk_right:
                if not jumping and not falling:
                    characterx += 6
                if jumping or falling:
                    characterx += 12

                walk_index += 1

            if walk_left:
                if not jumping and not falling:
                    characterx -= 6
                if jumping or falling:
                    characterx -= 12
                walk_index += 1

            if not walk_right and not walk_left:
                walk_index = 0

            timing = pygame.time.Clock()
            timing.tick(30)

            if positionx + info.winfo_screenwidth() < info.winfo_screenwidth():
                positionx += 1
            elif positionx + info.winfo_screenwidth() < info.winfo_screenwidth():
                positionx -= 1

            screen.blit(background, (positionx, 0))

            if not grenadey >= 800:
                if facing_right:
                    if gun == 1:
                        screen.blit(sprites_load.character_animations_right[walk_index %
                                                                            len(
                                                                                sprites_load.character_animations_right)],
                                    (characterx, charactery))
                    if gun == 2:
                        screen.blit(sprites_load.rifle_animation_right[walk_index %
                                                                       len(sprites_load.rifle_animation_right)],
                                    (characterx, charactery))

                    if gun == 3:
                        screen.blit(sprites_load.shotgun_pistol_animations_right
                                    [walk_index % len(sprites_load.shotgun_pistol_animations_right)],
                                    (characterx, charactery))
                if facing_left:
                    if gun == 1:
                        screen.blit(sprites_load.character_animations_left[walk_index %
                                                                           len(
                                                                               sprites_load.character_animations_right)],
                                    (characterx, charactery))
                    if gun == 2:
                        screen.blit(
                            sprites_load.rifle_animation_left[walk_index % len(sprites_load.rifle_animation_left)],
                            (characterx, charactery))

                    if gun == 3:
                        screen.blit(sprites_load.shotgun_pistol_animations_left
                                    [walk_index % len(sprites_load.shotgun_pistol_animations_left)],
                                    (characterx, charactery))

            if entity_type == "lizard":
                screen.blit(sprites_load.spikes, (350, info.winfo_screenheight() - 75))
                screen.blit(sprites_load.spikes, (1100, info.winfo_screenheight() - 75))

                if 425 > characterx + 60 > 330:
                    if charactery + 150 > info.winfo_screenheight() - 75:
                        remained_lives -= 1
                        if characterx + 60 > 380:
                            characterx += 75
                        elif characterx + 60 < 360:
                            characterx -= 75
                        pygame.mixer.music.load("sounds/missile_shot_sound.mp3")
                        pygame.mixer.music.play(1)

                if 1175 > characterx + 60 > 1080:
                    if charactery + 150 > info.winfo_screenheight() - 75:
                        remained_lives -= 1
                        if characterx + 60 > 1130:
                            characterx += 75
                        elif characterx + 60 < 1110:
                            characterx -= 75
                        pygame.mixer.music.load("sounds/missile_shot_sound.mp3")
                        pygame.mixer.music.play(1)

            for i in range(freeze_left):
                screen.blit(sprites_load.time_freeze, (info.winfo_screenwidth() - (i * 60) - 90 + 20, 130))

            show_enemies.show(screen, zombie_anim_index, entity1x, entity2x, entity3x,
                              entity4x, entity5x, entity6x, entity_type, meteor1y, meteor2y, meteor3y, meteor4y,
                              meteor5y, missile1x, missile2x)

            if entity_type == "jinn":
                last_attack_time1 = True
                last_attack_time2 = True

            if entity_type == "lizard":
                last_attack_time1 = False
                last_attack_time2 = False

            if jumping:
                if not charactery < info.winfo_screenheight() - 350:
                    charactery -= 20
                else:
                    jumping = False
                    falling = True

            elif falling:
                if charactery <= info.winfo_screenheight() - 190:
                    charactery += 20
                else:
                    falling = False

            if gun == 1:
                for i in range(bullets_left):
                    screen.blit(sprites_load.bullet, (i * 10 + 10, 10))

            for i in range(int(grenades_left)):
                screen.blit(sprites_load.grenade, (info.winfo_screenwidth() - (i * 50) - 120 + 20, 60))

            if gun == 2:
                for i in range(rifle_ammo):
                    screen.blit(sprites_load.rifle_ammo, (i * 30, -10))

            if gun == 3:
                for i in range(shotgun_pistol_ammo):
                    screen.blit(sprites_load.spammo, (i * 10 + 15, 40))

            for i in range(dynamites_left):
                screen.blit(sprites_load.dynamite, (i * 20, 100))

            if gun == 1:
                screen.blit(sprites_load.pistol, (700, 60))

            if gun == 2:
                screen.blit(sprites_load.rifle, (700, 60))

            if gun == 3:
                screen.blit(sprites_load.s_pistol, (700, 60))

            if entity_type == "demon" or entity_type == "jinn" or entity_type == "lizard":
                enemy_y = info.winfo_screenheight() - 190

            if fired_right:
                if target[1] > enemy_y:
                    if not shoot:
                        if entity2x < info.winfo_screenwidth() or entity4x < info.winfo_screenwidth() or \
                                entity6x < info.winfo_screenwidth():
                            pygame.mixer.music.load("sounds/hit_target.mp3")
                            pygame.mixer.music.play(1)
                            if random.randint(1, 3) == 2:
                                bullets_left = bullets_left + 1

                            if random.randint(1, 6) == 3:
                                rifle_ammo += 1

                            shoot = True

                            if entity2x < entity4x and entity4x < entity6x:
                                entity2_lives -= 1

                            elif entity2x > entity4x and entity4x < entity6x:
                                entity4_lives -= 1

                            else:
                                entity6_lives -= 1
                        else:
                            if first:
                                pygame.mixer.music.load("sounds/firearm.mp3")
                                pygame.mixer.music.play(1)
                                first = False

                if time.time() - fired_time > 0.3:
                    first = True
                    shoot = False
                    fired_right = False
                pygame.draw.line(screen, (0, 0, 0), (characterx + 100, charactery + 30), target, 2)

            # pygame.draw.rect(screen, (0, 0, 255), (685, 0, 115, 50))
            screen.blit(time_passed, (700, 10))

            if fired_left:
                if not shoot:
                    if target[1] > enemy_y:
                        if entity1x > -100 or entity3x > -100 or entity5x > -100:
                            if not shoot:
                                pygame.mixer.music.load("sounds/hit_target.mp3")
                                pygame.mixer.music.play(1)
                                if random.randint(1, 3) == 2:
                                    bullets_left = bullets_left + 1

                                if random.randint(1, 6) == 3:
                                    rifle_ammo += 1

                                shoot = True

                                if entity1x > entity3x and entity3x > entity5x:
                                    entity1_lives -= 1

                                elif entity1x < entity3x and entity3x > entity5x:
                                    entity3_lives -= 1

                                else:
                                    entity5_lives -= 1

                        else:
                            if first:
                                pygame.mixer.music.load("sounds/firearm.mp3")
                                pygame.mixer.music.play(1)
                                first = False

                    else:
                        if first:
                            pygame.mixer.music.load("sounds/firearm.mp3")
                            pygame.mixer.music.play(1)
                            first = False

                if time.time() - fired_time > 0.3:
                    shoot = False
                    fired_left = False
                    first = True
                pygame.draw.line(screen, (0, 0, 0), (characterx, charactery + 30), target, 2)

            if grenade_threw:
                missile1x = -200
                missile2x = info.winfo_screenwidth() + 700

                screen.blit(sprites_load.grenade, (grenadex, grenadey))
                grenadey += 25

                if grenadey >= 800:
                    if first_time_sound:
                        pygame.mixer.music.load("sounds/explosion.mp3")
                        pygame.mixer.music.play(1)
                        first_time_sound = False

                    entity1x = -300
                    entity2x = info.winfo_screenwidth() + 600
                    entity3x = -400

                    missile1x = -200
                    missile2x = info.winfo_screenwidth() + 700

                    entity4x = info.winfo_screenwidth() + 800
                    entity5x = -600
                    entity6x = info.winfo_screenwidth() + 1000

                    screen.blit(sprites_load.explosion, (0, 0))

                    if not pygame.mixer.get_busy() and int(time.time() - grenade_time_start) >= 8:
                        grenadey = 0
                        grenade_threw = False
                        first_time_sound = True

            if entity1x >= characterx - 120 or entity3x >= characterx - 120 or entity5x >= characterx - 120:
                entity1x = -200
                entity3x = -400
                entity5x = -600

                entity2x = info.winfo_screenwidth()
                entity4x = info.winfo_screenwidth() + 200
                entity6x = info.winfo_screenwidth() + 400

                if entity_type == "demon" or "jinn":
                    remained_lives -= 1

                characterx = 1440 / 2

                life_loss = time.time()

            if entity2x <= characterx + 130 or entity4x <= characterx + 130 or entity6x <= characterx + 130:
                entity2x = info.winfo_screenwidth()
                entity4x = info.winfo_screenwidth() + 200
                entity6x = info.winfo_screenwidth() + 400

                entity1x = -200
                entity3x = -400
                entity5x = -600

                missile1x = -200
                missile2x = info.winfo_screenwidth() + 700

                if entity_type == "demon" or "jinn":
                    remained_lives -= 1

                characterx = 1440 / 2

                life_loss = time.time()

            screen.blit(sprites_load.cursor, (pygame.mouse.get_pos()[0] - 25, pygame.mouse.get_pos()[1] - 25))

            if not time.time() - life_loss >= 1:
                screen.fill((0, 0, 0))

            for i in range(remained_lives):
                screen.blit(sprites_load.heart, (i * 30 + info.winfo_screenwidth() - 200, 0))

            if last_attack_time1 and last_attack_time2:
                missile1x += 20
                missile2x -= 20

                if missile2x < -200:
                    missile2x = info.winfo_screenwidth() + 150

                if missile1x > info.winfo_screenwidth() + 200:
                    missile1x = - 200

                if missile1x > characterx:
                    if missile1x < characterx + 150:
                        if charactery + 150 > info.winfo_screenheight() - 70:
                            pygame.mixer.music.load("sounds/missile_shot_sound.mp3")
                            pygame.mixer.music.play(1)
                            remained_lives -= 1
                            missile1x = -200

                if missile2x < characterx + 150:
                    if missile2x > characterx:
                        if charactery + 150 > info.winfo_screenheight() - 70:
                            pygame.mixer.music.load("sounds/missile_shot_sound.mp3")
                            pygame.mixer.music.play(1)
                            remained_lives -= 1
                            missile2x = info.winfo_screenwidth() + 150

            if time.time() - episode_time >= 300 and not entity_type == "lizard":
                level_up_time = time.time()

                charactery -= 10

                entity1x -= 10
                entity3x -= 10
                entity5x -= 10

                entity2x += 10
                entity4x += 10
                entity6x += 10

            if time.time() - level_up_time <= 2 and charactery == 710:

                entity1x = -300
                entity2x = info.winfo_screenwidth() + 600
                entity3x = -400

                entity4x = info.winfo_screenwidth() + 800
                entity5x = -600
                entity6x = info.winfo_screenwidth() + 400

                if entity_type == "jinn":
                    screen.fill((0, 0, 0))

                    new_weapon = bigger_font.render("New Ability Unlocked:", True, (255, 255, 255))
                    new_weapon_2 = bigger_font.render("Press Space to jump", True, (255, 255, 255))
                    level_up_text = bigger_font.render("Level Up!", True, (255, 255, 255))
                    jump_text = bigger_font.render("Jump", True, (255, 255, 255))
                    screen.blit(level_up_text, (info.winfo_screenwidth() - 1400, 350))
                    screen.blit(new_weapon, (info.winfo_screenwidth() - 1400, 425))
                    screen.blit(jump_text, (info.winfo_screenwidth() - 900, 425))
                    screen.blit(new_weapon_2, (info.winfo_screenwidth() - 1400, 500))

                elif entity_type == "lizard":
                    screen.fill((0, 0, 0))
                    new_weapon = bigger_font.render("New Gadget Unlocked:", True, (255, 255, 255))
                    new_weapon_2 = bigger_font.render("Press R to use", True, (255, 255, 255))
                    level_up_text = bigger_font.render("Level Up!", True, (255, 255, 255))
                    new_gad = sprites_load.time_freeze_collection
                    screen.blit(level_up_text, (info.winfo_screenwidth() - 1400, 350))
                    screen.blit(new_weapon, (info.winfo_screenwidth() - 1400, 425))
                    screen.blit(new_gad, (info.winfo_screenwidth() - 900, 400))
                    screen.blit(new_weapon_2, (info.winfo_screenwidth() - 1400, 500))

            if charactery <= -150:
                charactery = 710
                episode_time = time.time() + 3

                if entity_type == "demon":
                    entity_type = "jinn"
                    print(last_attack_time1)
                    original_lives = 1

                elif entity_type == "jinn":
                    entity_type = "lizard"
                    print(last_attack_time1)
                    original_lives = 1

                entity1_lives = original_lives
                entity2_lives = original_lives
                entity3_lives = original_lives

                entity4_lives = original_lives
                entity5_lives = original_lives
                entity6_lives = original_lives

                f = open("save.txt", "w+")
                f.write(f'''{entity1_lives} {entity2_lives} {entity3_lives} {entity4_lives} {entity5_lives} 
                            {entity6_lives} {entity1x} {entity2x} {entity3x} {entity4x}  {entity5x}  {entity6x} 
                            {time.time() - starting_time} {characterx} {remained_lives} {bullets_left} 
                            {rifle_ammo} {shp_str} {grn_str} {entity_type} {dynamites_left} {freeze_left}''')
                f.close()

                mon = open("money.txt", "w+")

                mon.write(str(money))

                mon.close()

            if dynamite_threw:
                if time.time() - thrown_time >= 0.5:
                    if entity1x > entity3x and entity3x > entity5x:
                        entity1_lives -= 2

                    elif entity1x < entity3x and entity3x > entity5x:
                        entity3_lives -= 2

                    else:
                        entity5_lives -= 2
                    dynamite_threw = False

                screen.blit(sprites_load.dynamite_explosion, (characterx - 250, charactery - 200))

        elif not quest_one:
            if not quest_two:
                charactery = info.winfo_screenheight() - 330
                for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_d:
                            facing_left = False
                            facing_right = True

                            walk_right = True

                        if event.key == pygame.K_a:
                            facing_left = True
                            facing_right = False

                            walk_left = True

                        if event.key == pygame.K_q:
                            pygame.quit()
                            sys.exit()

                    if event.type == pygame.KEYUP:
                        if event.key == pygame.K_d:
                            walk_right = False

                        if event.key == pygame.K_a:
                            walk_left = False

                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if shop:
                            if pygame.mouse.get_pos()[1] < info.winfo_screenheight() / 7:
                                if 190 > pygame.mouse.get_pos()[0] > 100:
                                    if money >= 35:
                                        bullets_left += 5
                                        money -= 35

                                if 530 > pygame.mouse.get_pos()[0] > 400:
                                    if money >= 35:
                                        rifle_ammo += 2
                                        money -= 35

                                if 800 > pygame.mouse.get_pos()[0] > 740:
                                    if money >= 25:
                                        shotgun_pistol_ammo += 2
                                        money -= 25

                if walk_right:
                    characterx += 10
                    walk_index += 1

                if walk_left:
                    characterx -= 10
                    walk_index += 1

                screen.blit(sprites_load.starting_background, (0, 0))
                if page1:
                    screen.blit(sprites_load.quest_panel, (100, info.winfo_screenheight() - 430))

                if os.path.exists("level_save"):
                    c = open("level_save", "r")

                    if c.read() == "quest 2":
                        screen.blit(sprites_load.boss1_decor, (500, 400))

                if characterx > info.winfo_screenwidth():
                    page1 = False
                    page2 = True

                    characterx = 0

                if characterx + 150 < 0:
                    page1 = True
                    page2 = False

                    characterx = info.winfo_screenwidth() - 150

                if page1:
                    if characterx > 100:
                        if characterx < 350:
                            if os.path.exists("level_save"):
                                c = open("level_save", "r")
                                if c.read() == "quest 2":
                                    entity_type = "demon"
                                    episode_time = time.time()
                                    starting_time = time.time()
                                    entity1x = -100
                                    entity3x = -300
                                    entity5x = -500

                                    entity2x = info.winfo_screenwidth() + 200
                                    entity4x = info.winfo_screenwidth() + 400
                                    entity6x = info.winfo_screenwidth() + 600

                                    quest_two = True
                                    quest_one = False
                                    remained_lives = 3
                                    charactery = info.winfo_screenheight() - 190
                            elif not os.path.exists("level_save"):
                                charactery = info.winfo_screenheight() - 190
                                quest_one = True

                if page2:
                    screen.blit(sprites_load.shop, (info.winfo_screenwidth() - 640, info.winfo_screenheight() - 500))

                    if info.winfo_screenwidth() - 340 > characterx > info.winfo_screenwidth() - 740:
                        shop = True

                    else:
                        shop = False

                if shop:
                    screen.blit(sprites_load.shop_ui, (0, 0))
                    for i in range(5):
                        screen.blit(sprites_load.bullet, (i * 10 + 100, 30))

                    pygame.draw.rect(screen, (0, 0, 0), (190, 65, 30, 5))
                    pygame.draw.rect(screen, (0, 0, 0), (190, 75, 30, 5))

                    for i in range(2):
                        screen.blit(sprites_load.rifle_ammo, (i * 30 + 400, -20))

                    pygame.draw.rect(screen, (0, 0, 0), (530, 65, 30, 5))
                    pygame.draw.rect(screen, (0, 0, 0), (530, 75, 30, 5))

                    for i in range(2):
                        screen.blit(sprites_load.spammo, (i * 15 + 740, 40))

                    pygame.draw.rect(screen, (0, 0, 0), (800, 65, 30, 5))
                    pygame.draw.rect(screen, (0, 0, 0), (800, 75, 30, 5))

                    price_spammo = bigger_font.render("25", True, (0, 0, 0))
                    price_rifle_ammo = bigger_font.render("35", True, (0, 0, 0))
                    price_bullet = bigger_font.render("35", True, (0, 0, 0))

                    money_text = bigger_font.render(str(money), True, (0, 0, 0))

                    screen.blit(price_spammo, (860, 50))
                    screen.blit(sprites_load.money, (915, 55))

                    screen.blit(price_rifle_ammo, (590, 50))
                    screen.blit(sprites_load.money, (645, 55))

                    screen.blit(price_bullet, (250, 50))
                    screen.blit(sprites_load.money, (305, 55))

                    screen.blit(money_text, (info.winfo_screenwidth() - 200, 50))
                    screen.blit(sprites_load.money, (info.winfo_screenwidth() - 100, 55))

                if facing_right:
                    screen.blit(sprites_load.character_animations_right[walk_index %
                                                                        len(sprites_load.character_animations_right)],
                                (characterx, charactery))
                if facing_left:
                    screen.blit(sprites_load.character_animations_left[walk_index %
                                                                       len(sprites_load.character_animations_right)],
                                (characterx, charactery))

    if first_start:
        save.clear()

        if os.path.exists("save.txt"):
            read = open("save.txt", "r")
            read_file = read.read()

            m = open("money.txt")
            money = int(m.read())
            m.close()

        for i in read_file.split(" "):
            if not i == '' and not i == "\n":
                save.append(i)

        if not read:
            if os.path.exists("money.txt"):
                m = open("money.txt")

                money = int(m.read())

                m.close()
            else:
                money = 0

            dynamites_left = 0
            starting_time = 0

            episode_time = 0

            bullets_left = 10
            grenades_left = 0

            walk_right = False
            walk_left = False

            walk_index = 0

            level_up_time = 0

            characterx = info.winfo_screenwidth() / 2
            charactery = info.winfo_screenheight() - 190

            life_loss = 0

            grenade_time_start = 0

            facing_left = False
            facing_right = True

            fired_left = False
            fired_right = False

            grenade_threw = False

            fired_time = 0

            font = pygame.font.Font("freesansbold.ttf", 20)
            bigger_font = pygame.font.Font("freesansbold.ttf", 40)

            retreat = None

            target = None

            entity1x = -100

            entity3x = -300
            entity5x = -500

            shotgun_pistol_ammo = 5
            last_given_spammo = 0

            last_give_dynamite = 0

            entity2x = info.winfo_screenwidth() + 200
            entity4x = info.winfo_screenwidth() + 400
            entity6x = info.winfo_screenwidth() + 600

            enemy_y = info.winfo_screenheight() - 190

            zombie_anim_index = 0

            shoot = False

            first_start = True

            gun = 1

            original_lives = 1

            last_given_bullet = 0
            last_given_grenade = 0

            grenadex = 1440 / 2
            grenadey = 0

            first = True

            first_time_sound = True

            rifle_ammo = 3

            entity_type = "zombie"

            background = sprites_load.background

            entity1_lives = original_lives
            entity2_lives = original_lives
            entity3_lives = original_lives

            entity4_lives = original_lives
            entity5_lives = original_lives
            entity6_lives = original_lives

            remained_lives = 3

        else:
            last_give_dynamite = 0
            starting_time = time.time() - float(save[12])

            bullets_left = int(save[15])
            grenades_left = float(save[-4])

            walk_right = False
            walk_left = False

            walk_index = 0

            level_up_time = 0

            characterx = float(save[13])
            charactery = info.winfo_screenheight() - 190

            life_loss = 0

            grenade_time_start = 0

            facing_left = False
            facing_right = True

            fired_left = False
            fired_right = False

            grenade_threw = False

            fired_time = 0

            font = pygame.font.Font("freesansbold.ttf", 20)
            bigger_font = pygame.font.Font("freesansbold.ttf", 40)

            retreat = None

            target = None

            entity1x = int(save[6])

            entity3x = int(save[8])
            entity5x = int(save[10])

            shotgun_pistol_ammo = int(save[17])
            last_given_spammo = 0

            entity2x = int(save[7])
            entity4x = int(save[9])
            entity6x = int(save[11])

            enemy_y = info.winfo_screenheight() - 190

            zombie_anim_index = 0

            shoot = False

            first_start = True

            gun = 1

            original_lives = 1

            last_given_bullet = 0
            last_given_grenade = 0

            grenadex = 1440 / 2
            grenadey = 0

            first = True

            first_time_sound = True

            rifle_ammo = int(save[16])

            entity_type = save[-3]

            dynamites_left = int(save[-2])

            freeze_left = int(save[-1])

            if entity_type == "zombie" or entity_type == "demon":
                episode_time = time.time() - (time.time() - starting_time)
            elif entity_type == "dino" or entity_type == "jinn":
                episode_time = time.time() - (time.time() - starting_time) + 311
            elif entity_type == "orc":
                episode_time = time.time() - (time.time() - starting_time) + 622
            elif entity_type == "knight":
                episode_time = time.time() - (time.time() - starting_time) + 933

            background = sprites_load.background

            entity1_lives = int(save[0])
            entity2_lives = int(save[1])
            entity3_lives = int(save[2])

            entity4_lives = int(save[3])
            entity5_lives = int(save[4])
            entity6_lives = int(save[5])

            remained_lives = int(save[14])

        pygame.mouse.set_visible(True)
        screen.blit(sprites_load.entry_page, (0, 0))

        title = bigger_font.render("Shoot the Monsters", True, (0, 255, 255))
        play = font.render("Play", True, (0, 0, 0))
        quit_game = font.render("Quit", True, (0, 0, 0))
        reset = font.render("Reset", True, (0, 0, 0))
        credit = font.render("Made by Omer", True, (0, 0, 0))

        screen.blit(title, (info.winfo_screenwidth() / 2 - 170, 350))
        screen.blit(play, (info.winfo_screenwidth() / 2 - 25, 450))
        screen.blit(quit_game, (info.winfo_screenwidth() / 2 - 25, 480))
        screen.blit(reset, (info.winfo_screenwidth() / 2 - 30, 510))
        screen.blit(credit, (info.winfo_screenwidth() / 2 - 70, 540))

        if entity_type == "boss1":
            entity6_lives = 10

        for e in pygame.event.get():
            if e.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pos()[1] > 450:
                    if pygame.mouse.get_pos()[1] < 475:
                        first_start = False
                if pygame.mouse.get_pos()[1] > 480:
                    if pygame.mouse.get_pos()[1] < 510:
                        pygame.quit()
                        sys.exit()
                if pygame.mouse.get_pos()[1] > 510:
                    if pygame.mouse.get_pos()[1] < 530:
                        if os.path.exists("save.txt"):
                            os.remove("save.txt")
                        if os.path.exists("level_save"):
                            os.remove("level_save")
                        if os.path.exists("money.txt"):
                            os.remove("money.txt")
                        pygame.quit()
                        sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()

    pygame.display.update()
