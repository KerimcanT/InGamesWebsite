import pygame
import tkinter

info = tkinter.Tk()

width = int(info.winfo_screenwidth())
height = int(info.winfo_screenheight())

bullet_image = pygame.image.load("sprites/bullet.png")
bullet = pygame.transform.scale(bullet_image, (50, 80))

money_image = pygame.image.load("sprites/money.png")
money = pygame.transform.scale(money_image, (25, 25))

rifle_ammo_image = pygame.image.load("sprites/rifle_ammo.png")
rifle_ammo = pygame.transform.scale(rifle_ammo_image, (150, 150))

spammo_image = pygame.image.load("sprites/spammo.png")
spammo = pygame.transform.scale(spammo_image, (50, 50))

time_freeze_image = pygame.image.load("sprites/time_freeze.png")
time_freeze = pygame.transform.scale(time_freeze_image, (50, 50))
time_freeze_collection = pygame.transform.scale(time_freeze_image, (80, 80))

starting_background_image = pygame.image.load("sprites/starting_background.png")
starting_background = pygame.transform.scale(starting_background_image, (width, height))

quest_panel_image = pygame.image.load("sprites/quests.png")
quest_panel = pygame.transform.scale(quest_panel_image, (300, 240))

demon_background_image = pygame.image.load("sprites/demon_background.jpg")
demon_background = pygame.transform.scale(demon_background_image, (width, height))

lizard_background_image = pygame.image.load("sprites/lizard_background.jpg")
lizard_background = pygame.transform.scale(lizard_background_image, (width, height))

spikes_image = pygame.image.load("sprites/spikes.png")
spikes = pygame.transform.scale(spikes_image, (75, 40))

pistol_image = pygame.image.load("sprites/pistol.png")
pistol = pygame.transform.scale(pistol_image, (100, 50))

s_pistol_image = pygame.image.load("sprites/shotgun_pistol.png")
s_pistol = pygame.transform.scale(s_pistol_image, (100, 50))
level_up_version_spistol = pygame.transform.scale(s_pistol_image, (100, 50))

rifle_image = pygame.image.load("sprites/shotgun.png")
rifle = pygame.transform.scale(rifle_image, (100, 50))
level_up_version_rifle = pygame.transform.scale(rifle_image, (250, 125))

grenade_image = pygame.image.load("sprites/grenade.png")
grenade = pygame.transform.scale(grenade_image, (100, 80))

dynamite_image = pygame.image.load("sprites/dynamite.png")
dynamite = pygame.transform.scale(dynamite_image, (50, 50))
level_up_version_dynamite = pygame.transform.scale(dynamite_image, (50, 100))

dynamite_explosion_image = pygame.image.load("sprites/dynamite_exlosion.png")
dynamite_explosion = pygame.transform.scale(dynamite_explosion_image, (500, 500))

shop_image = pygame.image.load("sprites/shop.png")
shop = pygame.transform.scale(shop_image, (400, 300))

shop_ui_image = pygame.image.load("sprites/shop_ui.png")
shop_ui = pygame.transform.scale(shop_ui_image, (width, int(height / 7)))

explosion_image = pygame.image.load("sprites/explode.png")
explosion = pygame.transform.scale(explosion_image, (width, height))

background_image = pygame.image.load("sprites/background.jpg")
background = pygame.transform.scale(background_image, (width, height))

jungle_background_image = pygame.image.load("sprites/jungle_background.png")
jungle_background = pygame.transform.scale(jungle_background_image, (width,
                                                                     height))

castle_background_image = pygame.image.load("sprites/castle_background.jpg")
castle_background = pygame.transform.scale(castle_background_image, (width,
                                                                     height))

orc_background_image = pygame.image.load("sprites/orc_background.png")
orc_background = pygame.transform.scale(orc_background_image, (width, height))

hell_background_image = pygame.image.load("sprites/boss1_background.jpg")
hell_background = pygame.transform.scale(hell_background_image, (width,
                                                                 height))

boss1_image = pygame.image.load("sprites/boss1.png")
boss1 = pygame.transform.scale(boss1_image, (400, 800))
boss1_decor = pygame.transform.scale(boss1_image, (100, 200))

jinn_background_image = pygame.image.load("sprites/jinn_background.png")
jinn_background = pygame.transform.scale(jinn_background_image, (width, height))

meteor_image = pygame.image.load("sprites/meteor.png")
meteor = pygame.transform.scale(meteor_image, (100, 150))

character_image_shotgun_pistol_stationary_left = pygame.image.load("sprites/stationary_left_shotgun_pistol.png")
character_shotgun_pistol_stationary_left = pygame.transform.scale(character_image_shotgun_pistol_stationary_left,
                                                                  (175, 150))

character_image_shotgun_pistol_stationary_right = pygame.image.load("sprites/stationary_right_shotgun_pistol.png")
character_shotgun_pistol_stationary_right = pygame.transform.scale(character_image_shotgun_pistol_stationary_right,
                                                                   (175, 150))

character_image_shotgun_pistol_walk1_left = pygame.image.load("sprites/walk1_left_shotgun_pistol.png")
character_shotgun_pistol_walk1_left = pygame.transform.scale(character_image_shotgun_pistol_walk1_left,
                                                             (175, 150))

character_image_shotgun_pistol_walk1_right = pygame.image.load("sprites/walk1_right_shotgun_pistol.png")
character_shotgun_pistol_walk1_right = pygame.transform.scale(character_image_shotgun_pistol_walk1_right,
                                                              (175, 150))

character_image_shotgun_pistol_walk2_left = pygame.image.load("sprites/walk2_left_shotgun_pistol.png")
character_shotgun_pistol_walk2_left = pygame.transform.scale(character_image_shotgun_pistol_walk2_left,
                                                             (175, 150))

character_image_shotgun_pistol_walk2_right = pygame.image.load("sprites/walk2_right_shotgun_pistol.png")
character_shotgun_pistol_walk2_right = pygame.transform.scale(character_image_shotgun_pistol_walk2_right,
                                                              (175, 150))

character_image_stationary_right = pygame.image.load("sprites/stationary.png")
character_stationary_right = pygame.transform.scale(character_image_stationary_right, (int(100 * 1.5), int(100 * 1.5)))

character_image_stationary_rifle_right = pygame.image.load("sprites/stationary_rifle_right.png")
character_stationary_rifle_right = pygame.transform.scale(character_image_stationary_rifle_right, (int(90 * 1.5),
                                                                                                   int(100 * 1.5)))

character_image_stationary_rifle_left = pygame.image.load("sprites/stationary_rifle_left.png")
character_stationary_rifle_left = pygame.transform.scale(character_image_stationary_rifle_left, (int(90 * 1.5),
                                                                                                 int(100 * 1.5)))

character_image_walking1_right = pygame.image.load("sprites/walk1.png")
character_walking1_right = pygame.transform.scale(character_image_walking1_right, (int(100 * 1.5), int(100 * 1.5)))

character_image_walking1_right_rifle = pygame.image.load("sprites/walk1_rifle_right.png")
character_walking1_rifle_right = pygame.transform.scale(character_image_walking1_right_rifle, (int(110 * 1.5),
                                                                                               int(100 * 1.5)))

character_image_walking1_left_rifle = pygame.image.load("sprites/walk1_rifle_left.png")
character_walking1_rifle_left = pygame.transform.scale(character_image_walking1_left_rifle, (int(110 * 1.5),
                                                                                             int(100 * 1.5)))

character_image_walking2_right = pygame.image.load("sprites/walk2.png")
character_walking2_right = pygame.transform.scale(character_image_walking2_right, (int(100 * 1.5), int(100 * 1.5)))

character_image_walking2_right_rifle = pygame.image.load("sprites/walk2_rifle_right.png")
character_walking2_rifle_right = pygame.transform.scale(character_image_walking2_right_rifle, (int(100 * 1.5),
                                                                                               int(100 * 1.5)))

character_image_walking2_left_rifle = pygame.image.load("sprites/walk2_rifle_left.png")
character_walking2_rifle_left = pygame.transform.scale(character_image_walking2_left_rifle, (int(100 * 1.5),
                                                                                             int(100 * 1.5)))

character_image_stationary_left = pygame.image.load("sprites/stationary_left.png")
character_stationary_left = pygame.transform.scale(character_image_stationary_left, (int(100 * 1.5), int(100 * 1.5)))

character_image_walking1_left = pygame.image.load("sprites/walk1_left.png")
character_walking1_left = pygame.transform.scale(character_image_walking1_left, (int(100 * 1.5), int(100 * 1.5)))

character_image_walking2_left = pygame.image.load("sprites/walk2_left.png")
character_walking2_left = pygame.transform.scale(character_image_walking2_left, (int(100 * 1.5),int(100 * 1.5)))

zombie1_image_right = pygame.image.load("sprites/zombie1.png")
zombie1_right = pygame.transform.scale(zombie1_image_right, (int(100 * 1.5), int(100 * 1.5)))

zombie2_image_right = pygame.image.load("sprites/zombie2.png")
zombie2_right = pygame.transform.scale(zombie2_image_right, (int(100 * 1.5), int(100 * 1.5)))

zombie3_image_right = pygame.image.load("sprites/zombie3.png")
zombie3_right = pygame.transform.scale(zombie3_image_right, (int(100 * 1.5), int(100 * 1.5)))

zombie4_image_right = pygame.image.load("sprites/zombie4.png")
zombie4_right = pygame.transform.scale(zombie4_image_right, (int(100 * 1.5), int(100 * 1.5)))

zombie1_image_left = pygame.image.load("sprites/zombie1_left.png")
zombie1_left = pygame.transform.scale(zombie1_image_left, (int(100 * 1.5), int(100 * 1.5)))

zombie2_image_left = pygame.image.load("sprites/zombie2_left.png")
zombie2_left = pygame.transform.scale(zombie2_image_left, (int(100 * 1.5), int(100 * 1.5)))

zombie3_image_left = pygame.image.load("sprites/zombie3_left.png")
zombie3_left = pygame.transform.scale(zombie3_image_left, (int(100 * 1.5), int(100 * 1.5)))

zombie4_image_left = pygame.image.load("sprites/zombie4_left.png")
zombie4_left = pygame.transform.scale(zombie4_image_left, (int(100 * 1.5), int(100 * 1.5)))

dino1_image_left = pygame.image.load("sprites/dino_left1.png")
dino1_left = pygame.transform.scale(dino1_image_left, (225, 200))

dino2_image_left = pygame.image.load("sprites/dino_left2.png")
dino2_left = pygame.transform.scale(dino2_image_left, (225, 200))

dino3_image_left = pygame.image.load("sprites/dino_left3.png")
dino3_left = pygame.transform.scale(dino3_image_left, (225, 200))

entry_page_image = pygame.image.load("sprites/entry_page.png")
entry_page = pygame.transform.scale(entry_page_image, (width, height))

dino1_image_right = pygame.image.load("sprites/dino_right1.png")
dino1_right = pygame.transform.scale(dino1_image_right, (225, 200))

dino2_image_right = pygame.image.load("sprites/dino_right2.png")
dino2_right = pygame.transform.scale(dino2_image_right, (225, 200))

dino3_image_right = pygame.image.load("sprites/dino_right3.png")
dino3_right = pygame.transform.scale(dino3_image_right, (225, 200))

orc_stationary_right_image = pygame.image.load("sprites/orc_stationary_right.png")
orc_stationary_right = pygame.transform.scale(orc_stationary_right_image, (150, 150))

orc_stationary_left_image = pygame.image.load("sprites/orc_stationary_left.png")
orc_stationary_left = pygame.transform.scale(orc_stationary_left_image, (150, 150))

orc_walk1_right_image = pygame.image.load("sprites/orc_walk1_right.png")
orc_walk1_right = pygame.transform.scale(orc_walk1_right_image, (150, 150))

orc_walk1_left_image = pygame.image.load("sprites/orc_walk1_left.png")
orc_walk1_left = pygame.transform.scale(orc_walk1_left_image, (150, 150))

orc_walk2_right_image = pygame.image.load("sprites/orc_walk2_right.png")
orc_walk2_right = pygame.transform.scale(orc_walk2_right_image, (150, 150))

orc_walk2_left_image = pygame.image.load("sprites/orc_walk2_left.png")
orc_walk2_left = pygame.transform.scale(orc_walk2_left_image, (150, 150))

knight_stationary_right_image = pygame.image.load("sprites/knight_stationary_right.png")
knight_stationary_right = pygame.transform.scale(knight_stationary_right_image, (150, 150))

knight_stationary_left_image = pygame.image.load("sprites/knight_stationary_left.png")
knight_stationary_left = pygame.transform.scale(knight_stationary_left_image, (150, 150))

knight_walk1_right_image = pygame.image.load("sprites/knight_walk1_right.png")
knight_walk1_right = pygame.transform.scale(knight_walk1_right_image, (150, 150))

knight_walk1_left_image = pygame.image.load("sprites/knight_walk1_left.png")
knight_walk1_left = pygame.transform.scale(knight_walk1_left_image, (150, 150))

knight_walk2_right_image = pygame.image.load("sprites/knight_walk2_right.png")
knight_walk2_right = pygame.transform.scale(knight_walk2_right_image, (150, 150))

knight_walk2_left_image = pygame.image.load("sprites/knight_walk2_left.png")
knight_walk2_left = pygame.transform.scale(knight_walk2_left_image, (150, 150))

demon_walk1_right_image = pygame.image.load("sprites/demon_walk1_right.png")
demon_walk1_right = pygame.transform.scale(demon_walk1_right_image, (150, 150))

demon_walk2_right_image = pygame.image.load("sprites/demon_walk2_right.png")
demon_walk2_right = pygame.transform.scale(demon_walk2_right_image, (150, 150))

demon_walk3_right_image = pygame.image.load("sprites/demon_walk3_right.png")
demon_walk3_right = pygame.transform.scale(demon_walk3_right_image, (150, 150))

demon_walk4_right_image = pygame.image.load("sprites/demon_walk4_right.png")
demon_walk4_right = pygame.transform.scale(demon_walk4_right_image, (150, 150))

demon_walk1_left_image = pygame.image.load("sprites/demon_walk1_left.png")
demon_walk1_left = pygame.transform.scale(demon_walk1_left_image, (150, 150))

demon_walk2_left_image = pygame.image.load("sprites/demon_walk2_left.png")
demon_walk2_left = pygame.transform.scale(demon_walk2_left_image, (150, 150))

demon_walk3_left_image = pygame.image.load("sprites/demon_walk3_left.png")
demon_walk3_left = pygame.transform.scale(demon_walk3_left_image, (150, 150))

demon_walk4_left_image = pygame.image.load("sprites/demon_walk4_left.png")
demon_walk4_left = pygame.transform.scale(demon_walk4_left_image, (150, 150))

jinn_walk1_right_image = pygame.image.load("sprites/jinn_walk1_right.png")
jinn_walk1_right = pygame.transform.scale(jinn_walk1_right_image, (150, 150))

jinn_walk2_right_image = pygame.image.load("sprites/jinn_walk2_right.png")
jinn_walk2_right = pygame.transform.scale(jinn_walk2_right_image, (150, 150))

jinn_walk3_right_image = pygame.image.load("sprites/jinn_walk3_right.png")
jinn_walk3_right = pygame.transform.scale(jinn_walk3_right_image, (150, 150))

jinn_walk4_right_image = pygame.image.load("sprites/jinn_walk4_right.png")
jinn_walk4_right = pygame.transform.scale(jinn_walk4_right_image, (150, 150))

jinn_walk1_left_image = pygame.image.load("sprites/jinn_walk1_left.png")
jinn_walk1_left = pygame.transform.scale(jinn_walk1_left_image, (150, 150))

jinn_walk2_left_image = pygame.image.load("sprites/jinn_walk2_left.png")
jinn_walk2_left = pygame.transform.scale(jinn_walk2_left_image, (150, 150))

jinn_walk3_left_image = pygame.image.load("sprites/jinn_walk3_left.png")
jinn_walk3_left = pygame.transform.scale(jinn_walk3_left_image, (150, 150))

jinn_walk4_left_image = pygame.image.load("sprites/jinn_walk4_left.png")
jinn_walk4_left = pygame.transform.scale(jinn_walk4_left_image, (150, 150))

lizard_walk1_right_image = pygame.image.load("sprites/lizard_walk1_right.png")
lizard_walk1_right = pygame.transform.scale(lizard_walk1_right_image, (150, 150))

lizard_walk2_right_image = pygame.image.load("sprites/lizard_walk2_right.png")
lizard_walk2_right = pygame.transform.scale(lizard_walk2_right_image, (150, 150))

lizard_walk3_right_image = pygame.image.load("sprites/lizard_walk3_right.png")
lizard_walk3_right = pygame.transform.scale(lizard_walk3_right_image, (150, 150))

lizard_walk4_right_image = pygame.image.load("sprites/lizard_walk4_right.png")
lizard_walk4_right = pygame.transform.scale(lizard_walk4_right_image, (150, 150))

lizard_walk1_left_image = pygame.image.load("sprites/lizard_walk1_left.png")
lizard_walk1_left = pygame.transform.scale(lizard_walk1_left_image, (150, 150))

lizard_walk2_left_image = pygame.image.load("sprites/lizard_walk2_left.png")
lizard_walk2_left = pygame.transform.scale(lizard_walk2_left_image, (150, 150))

lizard_walk3_left_image = pygame.image.load("sprites/lizard_walk3_left.png")
lizard_walk3_left = pygame.transform.scale(lizard_walk3_left_image, (150, 150))

lizard_walk4_left_image = pygame.image.load("sprites/lizard_walk4_left.png")
lizard_walk4_left = pygame.transform.scale(lizard_walk4_left_image, (150, 150))

cursor_image = pygame.image.load("sprites/cursor.png")
cursor = pygame.transform.scale(cursor_image, (50, 50))

heart_image = pygame.image.load("sprites/heart.png")
heart = pygame.transform.scale(heart_image, (150, 100))

missile_left_image = pygame.image.load("sprites/magic_attack_left.png")
missile_left = pygame.transform.scale(missile_left_image, (150, 50))

missile_right_image = pygame.image.load("sprites/magic_attack_right.png")
missile_right = pygame.transform.scale(missile_right_image, (150, 50))

orc_animations_right = [orc_stationary_right, orc_stationary_right, orc_stationary_right,
                        orc_walk1_right, orc_walk1_right, orc_walk1_right,
                        orc_walk2_right, orc_walk2_right, orc_walk2_right]

orc_animations_left = [orc_stationary_left, orc_stationary_left, orc_stationary_left,
                       orc_walk1_left, orc_walk1_left, orc_walk1_left,
                       orc_walk2_left, orc_walk2_left, orc_walk2_left]

knight_animations_right = [knight_stationary_right, knight_stationary_right, knight_stationary_right,
                           knight_walk1_right, knight_walk1_right, knight_walk1_right,
                           knight_walk2_right, knight_walk2_right, knight_walk2_right]

knight_animations_left = [knight_stationary_left, knight_stationary_left, knight_stationary_left,
                          knight_walk1_left, knight_walk1_left, knight_walk1_left,
                          knight_walk2_left, knight_walk2_left, knight_walk2_left]

character_animations_right = [character_stationary_right, character_stationary_right, character_stationary_right,
                              character_walking1_right, character_walking1_right,
                              character_walking1_right, character_walking2_right,
                              character_walking2_right, character_walking2_right]

character_animations_left = [character_stationary_left, character_stationary_left, character_stationary_left,
                             character_walking1_left, character_walking1_left,
                             character_walking1_left, character_walking2_left,
                             character_walking2_left, character_walking2_left]

shotgun_pistol_animations_left = [character_shotgun_pistol_stationary_left, character_shotgun_pistol_stationary_left,
                                  character_shotgun_pistol_stationary_left, character_shotgun_pistol_walk1_left,
                                  character_shotgun_pistol_walk1_left, character_shotgun_pistol_walk1_left,
                                  character_shotgun_pistol_walk2_left, character_shotgun_pistol_walk2_left,
                                  character_shotgun_pistol_walk2_left]

shotgun_pistol_animations_right = [character_shotgun_pistol_stationary_right, character_shotgun_pistol_stationary_right,
                                   character_shotgun_pistol_stationary_right, character_shotgun_pistol_walk1_right,
                                   character_shotgun_pistol_walk1_right, character_shotgun_pistol_walk1_right,
                                   character_shotgun_pistol_walk2_right, character_shotgun_pistol_walk1_right,
                                   character_shotgun_pistol_walk1_right]

rifle_animation_right = [character_stationary_rifle_right, character_stationary_rifle_right,
                         character_stationary_rifle_right, character_walking1_rifle_right,
                         character_walking1_rifle_right, character_walking1_rifle_right,
                         character_walking2_rifle_right, character_walking2_rifle_right,
                         character_walking2_rifle_right]

rifle_animation_left = [character_stationary_rifle_left, character_stationary_rifle_left,
                        character_stationary_rifle_left, character_walking1_rifle_left,
                        character_walking1_rifle_left, character_walking1_rifle_left,
                        character_walking2_rifle_left, character_walking2_rifle_left,
                        character_walking2_rifle_left]

zombie_animations_right = [zombie1_right, zombie1_right, zombie1_right, zombie2_right, zombie2_right, zombie2_right,
                           zombie3_right, zombie3_right, zombie3_right, zombie4_right, zombie4_right, zombie4_right]

zombie_animations_left = [zombie1_left, zombie1_left, zombie1_left, zombie2_left, zombie2_left, zombie2_left,
                          zombie3_left, zombie3_left, zombie3_left, zombie4_left, zombie4_left, zombie4_left]

dino_animations_right = [dino1_right, dino1_right, dino1_right, dino2_right, dino2_right, dino2_right,
                         dino3_right, dino3_right, dino3_right]

dino_animations_left = [dino1_left, dino1_left, dino1_left, dino2_left, dino2_left, dino2_left,
                        dino3_left, dino3_left, dino3_left]

demon_animations_right = [demon_walk1_right, demon_walk1_right, demon_walk2_right, demon_walk2_right, demon_walk3_right,
                          demon_walk3_right, demon_walk4_right, demon_walk4_right]

demon_animations_left = [demon_walk1_left, demon_walk1_left, demon_walk2_left, demon_walk2_left, demon_walk3_left,
                         demon_walk3_left, demon_walk4_left, demon_walk4_left]

jinn_animations_right = [jinn_walk1_right, jinn_walk1_right, jinn_walk2_right, jinn_walk2_right, jinn_walk3_right,
                         jinn_walk3_right, jinn_walk4_right, jinn_walk4_right]

jinn_animations_left = [jinn_walk1_left, jinn_walk1_left, jinn_walk2_left, jinn_walk2_left, jinn_walk3_left,
                        jinn_walk3_left, jinn_walk4_left, jinn_walk4_left]

lizard_animations_right = [lizard_walk1_right, lizard_walk1_right, lizard_walk2_right, lizard_walk2_right,
                           lizard_walk3_right, lizard_walk3_right, lizard_walk4_right, lizard_walk4_right]

lizard_animations_left = [lizard_walk1_left, lizard_walk1_left, lizard_walk2_left, lizard_walk2_left,
                          lizard_walk3_left, lizard_walk3_left, lizard_walk3_left, lizard_walk3_left]
